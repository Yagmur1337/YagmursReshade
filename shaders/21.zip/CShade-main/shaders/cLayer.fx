#define CSHADE_LAYER

/*
    This shader establishes a framework for layering and blending multiple shader effects. It does not apply direct visual effects but enables the use of up to 16 copy and 16 blend operations between different shader passes. This functionality facilitates complex multi-pass effects, allowing outputs from earlier shader passes to be copied and integrated with subsequent ones.
*/

#include "shared/cMacros.fxh"
#include "cLayer.fxh"

CSHADE_CREATE_INFO(
    "\n"
    "\t"CSHADE_UI_CAUTION("Enable to access copy/blend layer shaders.")"\n"
    "\n"
    "\t"CSHADE_UI_CAUTION("Supports up to 16 copy and blend operations.")"\n"
    "\n"
    "\t"CSHADE_UI_LINKED("You need to enable at least 1 Copy technique above this shader to work.")"\n"
    "\n"
)

#ifndef CLAYER_COPY_SHADERS
    #define CLAYER_COPY_SHADERS 1
#endif

#ifndef CLAYER_BLEND_SHADERS
    #define CLAYER_BLEND_SHADERS 1
#endif

/*
    Copy Shaders (up to 16)
*/

#if (CLAYER_COPY_SHADERS >= 1)
    CLAYER_CREATE_SHADER_COPY(1)
#endif
#if (CLAYER_COPY_SHADERS >= 2)
    CLAYER_CREATE_SHADER_COPY(2)
#endif
#if (CLAYER_COPY_SHADERS >= 3)
    CLAYER_CREATE_SHADER_COPY(3)
#endif
#if (CLAYER_COPY_SHADERS >= 4)
    CLAYER_CREATE_SHADER_COPY(4)
#endif
#if (CLAYER_COPY_SHADERS >= 5)
    CLAYER_CREATE_SHADER_COPY(5)
#endif
#if (CLAYER_COPY_SHADERS >= 6)
    CLAYER_CREATE_SHADER_COPY(6)
#endif
#if (CLAYER_COPY_SHADERS >= 7)
    CLAYER_CREATE_SHADER_COPY(7)
#endif
#if (CLAYER_COPY_SHADERS >= 8)
    CLAYER_CREATE_SHADER_COPY(8)
#endif
#if (CLAYER_COPY_SHADERS >= 9)
    CLAYER_CREATE_SHADER_COPY(9)
#endif
#if (CLAYER_COPY_SHADERS >= 10)
    CLAYER_CREATE_SHADER_COPY(10)
#endif
#if (CLAYER_COPY_SHADERS >= 11)
    CLAYER_CREATE_SHADER_COPY(11)
#endif
#if (CLAYER_COPY_SHADERS >= 12)
    CLAYER_CREATE_SHADER_COPY(12)
#endif
#if (CLAYER_COPY_SHADERS >= 13)
    CLAYER_CREATE_SHADER_COPY(13)
#endif
#if (CLAYER_COPY_SHADERS >= 14)
    CLAYER_CREATE_SHADER_COPY(14)
#endif
#if (CLAYER_COPY_SHADERS >= 15)
    CLAYER_CREATE_SHADER_COPY(15)
#endif
#if (CLAYER_COPY_SHADERS >= 16)
    CLAYER_CREATE_SHADER_COPY(16)
#endif

/*
    Blend Shaders (up to 16)
*/

#if (CLAYER_BLEND_SHADERS >= 1)
    CLAYER_CREATE_SHADER_BLEND(1)
#endif
#if (CLAYER_BLEND_SHADERS >= 2)
    CLAYER_CREATE_SHADER_BLEND(2)
#endif
#if (CLAYER_BLEND_SHADERS >= 3)
    CLAYER_CREATE_SHADER_BLEND(3)
#endif
#if (CLAYER_BLEND_SHADERS >= 4)
    CLAYER_CREATE_SHADER_BLEND(4)
#endif
#if (CLAYER_BLEND_SHADERS >= 5)
    CLAYER_CREATE_SHADER_BLEND(5)
#endif
#if (CLAYER_BLEND_SHADERS >= 6)
    CLAYER_CREATE_SHADER_BLEND(6)
#endif
#if (CLAYER_BLEND_SHADERS >= 7)
    CLAYER_CREATE_SHADER_BLEND(7)
#endif
#if (CLAYER_BLEND_SHADERS >= 8)
    CLAYER_CREATE_SHADER_BLEND(8)
#endif
#if (CLAYER_BLEND_SHADERS >= 9)
    CLAYER_CREATE_SHADER_BLEND(9)
#endif
#if (CLAYER_BLEND_SHADERS >= 10)
    CLAYER_CREATE_SHADER_BLEND(10)
#endif
#if (CLAYER_BLEND_SHADERS >= 11)
    CLAYER_CREATE_SHADER_BLEND(11)
#endif
#if (CLAYER_BLEND_SHADERS >= 12)
    CLAYER_CREATE_SHADER_BLEND(12)
#endif
#if (CLAYER_BLEND_SHADERS >= 13)
    CLAYER_CREATE_SHADER_BLEND(13)
#endif
#if (CLAYER_BLEND_SHADERS >= 14)
    CLAYER_CREATE_SHADER_BLEND(14)
#endif
#if (CLAYER_BLEND_SHADERS >= 15)
    CLAYER_CREATE_SHADER_BLEND(15)
#endif
#if (CLAYER_BLEND_SHADERS >= 16)
    CLAYER_CREATE_SHADER_BLEND(16)
#endif

technique cLayer
<
    ui_label = "CShade | Setup Layer Copy & Blend";
    ui_tooltip = "Blend with CBlend's copy texture.";
>
{ }
