/*----------------------------------------------|
| ::                NeoSSAO                  :: |
|-----------------------------------------------|
| Version: 2.2                                  |
| Author: Barbatos                              |
| License: MIT                                  |
|----------------------------------------------*/

#include ".\Includes\bb_reshade.fxh"
#include ".\Includes\bb_ui.fxh"
#define _BABA_USE_HALF 1
#include ".\Includes\bb_common.fxh"
#include ".\Includes\bb_depth.fxh"
#include ".\Includes\bb_normal.fxh"
#include ".\Includes\bb_mv.fxh"
#include ".\Includes\bb_taa.fxh"

//----------|
// :: UI :: |
//----------|

uniform float Intensity <
    ui_type = "drag";
    ui_category = "Basic Settings";
    ui_label = "Intensity";
    ui_min = 0.0; ui_max = 5.0; ui_step = 0.01;
> = 1.0;

uniform float Thickness <
    ui_type = "drag";
    ui_category = "Basic Settings";
    ui_label = "Thickness";
    ui_tooltip = "Assumed thickness of objects. Allows light to pass behind thin surfaces.";
    ui_min = 0.1; ui_max = 5.0;
    ui_step = 0.01;
> = 0.5;

uniform float AORadius <
    ui_type = "drag";
    ui_category = "Basic Settings";
    ui_label = "Radius";
    ui_min = 0.0; ui_max = 4.0; ui_step = 0.01;
> = 1.0;

uniform float RenderScale <
    ui_type = "drag";
    ui_category = "Performance";
    ui_label = "Render Resolution";
    ui_min = 0.1;
    ui_max = 1.0; ui_step = 0.01;
> = 1.0;

uniform int RaySteps <
    ui_type = "slider";
    ui_category = "Performance";
    ui_label = "Ray Steps";
    ui_min = 3;
    ui_max = 32;
> = 8;

uniform int SampleCount <
    ui_type = "slider";
    ui_category = "Performance";
    ui_label = "Slice Count";
    ui_min = 1;
    ui_max = 16;
> = 4;

uniform float FadeStart <
    ui_type = "slider";
    ui_category = "Fade Settings";
    ui_label = "Fade Start";
    ui_min = 0.0; ui_max = 1.0; ui_step = 0.01;
> = 0.0;

uniform float FadeEnd <
    ui_type = "slider";
    ui_category = "Fade Settings";
    ui_label = "Fade End";
    ui_min = 0.0; ui_max = 1.0; ui_step = 0.01;
> = 0.5;

uniform float BlurSharpness <
    ui_type = "drag";
    ui_category = "Denoising";
    ui_label = "Blur Sharpness";
    ui_tooltip = "Higher values preserve more edges but reduce blur strength.";
    ui_min = 0.0; ui_max = 5.0; ui_step = 0.1;
> = 1.0;

uniform bool EnableTAA <
    ui_category = "Temporal Anti-Aliasing";
    ui_label = "Enable TAA";
    ui_tooltip = "Enables temporal accumulation to reduce noise and flickering.";
> = false;

uniform float TemporalStability <
    ui_type = "drag";
    ui_category = "Temporal Anti-Aliasing";
    ui_label = "Temporal Stability";
    ui_min = 0.0; ui_max = 0.99; ui_step = 0.01;
    ui_tooltip = "Higher values = smoother but more ghosting. Lower values = faster reaction but more noise.";
> = 0.85;

uniform bool EnableDepthMultiplier <
    ui_type = "checkbox";
    ui_category = "Depth & Normals";
    ui_label = "Enable Depth Multiplier";
> = false;

uniform float DepthMultiplier <
    ui_type = "drag";
    ui_category = "Depth & Normals";
    ui_label = "Depth Multiplier";
    ui_min = 0.0; ui_max = 1.0; ui_step = 0.01;
> = 1.0;

uniform float DepthThreshold <
    ui_type = "slider";
    ui_category = "Depth & Normals";
    ui_label = "Sky Threshold";
    ui_min = 0.0; ui_max = 1.0; ui_step = 0.001;
> = 0.999;

uniform float FOV <
    ui_type = "slider";
    ui_category = "Depth & Normals";
    ui_label = "Field of View (Vertical)";
    ui_min = 1.0; ui_max = 120.0;
> = 75.0;

uniform float4 OcclusionColor <
    ui_type = "color";
    ui_category = "Debug & Style";
    ui_label = "Occlusion Color";
> = float4(0.0, 0.0, 0.0, 1.0);

uniform int ViewMode <
    ui_type = "combo";
    ui_category = "Debug & Style";
    ui_label = "View Mode";
    ui_items = "None\0AO Only\0Depth\0";
> = 0;

// Defines
#define SECTOR_COUNT 32
#define HALF_PI 1.57079632679
static const int BlurRadius = 2;

namespace NeoSSAO
{
#if _BABA_USE_LAUNCHER
    sampler sNormal
    {
        // Launcher's canonical full-precision normal; the RG encoding is legacy only.
        Texture = BaBa_Launcher::NormalMap;
        MagFilter = LINEAR;
        MinFilter = LINEAR;
    };
#else
    texture2D normalTex
    {
        Width = BUFFER_WIDTH;
        Height = BUFFER_HEIGHT;
        Format = RGBA16F;
    };
    sampler sNormal
    {
        Texture = normalTex;
    };
#endif

    float3 SampleNeoNormal(float2 uv)
    {
        float4 normalData = tex2Dlod(sNormal, float4(uv, 0.0, 0.0));
#if _BABA_USE_LAUNCHER
        return NM_SafeNormalize(normalData.rgb);
#else
        return NM_DecodeNormal(normalData.rg);
#endif
    }

    texture2D AO
    {
        Width = BUFFER_WIDTH;
        Height = BUFFER_HEIGHT;
        Format = R8;
    };
    sampler2D sAO
    {
        Texture = AO;
    };
    
    texture2D AOBlur
    {
        Width = BUFFER_WIDTH;
        Height = BUFFER_HEIGHT;
        Format = R8;
    };
    sampler2D sAOBlur
    {
        Texture = AOBlur;
    };

    texture2D History0
    {
        Width = BUFFER_WIDTH;
        Height = BUFFER_HEIGHT;
        Format = R8;
    };
    sampler sHistory0
    {
        Texture = History0;
    };

    texture2D History1
    {
        Width = BUFFER_WIDTH;
        Height = BUFFER_HEIGHT;
        Format = R8;
    };
    sampler sHistory1
    {
        Texture = History1;
    };

    //-------------|
    // :: Utility::|
    //-------------|

    struct VS_OUTPUT
    {
        float4 vpos : SV_Position;
        float2 uv : TEXCOORD0;
        float2 pScale : TEXCOORD1;
    };

    void VS_NeoSSAO(in uint id : SV_VertexID, out VS_OUTPUT outStruct)
    {
        outStruct.uv.x = (id == 2) ?
        2.0 : 0.0;
        outStruct.uv.y = (id == 1) ? 2.0 : 0.0;
        outStruct.vpos = float4(outStruct.uv * float2(2.0, -2.0) + float2(-1.0, 1.0), 0.0, 1.0);

        float fov_rad = FOV * (PI / 180.0);
        float y = tan(fov_rad * 0.5);
        outStruct.pScale = float2(y * bb::AspectRatio, y);
    }

    float GetBayer8x8(float2 uv)
    {
        int2 pixelPos = int2(uv * float2(BUFFER_WIDTH, BUFFER_HEIGHT));
        static const int bayer[64] =
        {
            0, 32, 8, 40, 2, 34, 10, 42, 48, 16, 56, 24, 50, 18, 58, 26,
            12, 44, 4, 36, 14, 46, 6, 38, 60, 28, 52, 20, 62, 30, 54, 22,
             3, 35, 11, 43, 1, 33, 9, 41, 51, 19, 59, 27, 49, 17, 57, 25,
      
       15, 47, 7, 39, 13, 45, 5, 37, 63, 31, 55, 23, 61, 29, 53, 21
        };
        return float(bayer[(uint(pixelPos.x) % 8u) + (uint(pixelPos.y) % 8u) * 8u]) * (1.0 / 64.0);
    }

    float GTAOFastAcos(float x)
    {
        float res = -0.156583 * abs(x) + HALF_PI;
        res *= sqrt(1.0 - abs(x));
        return x >= 0 ? res : PI - res;
    }
    
    float2 GTAOFastAcos(float2 x)
    {
        float2 res = -0.156583 * abs(x) + HALF_PI;
        res *= sqrt(1.0 - abs(x));
        return x >= 0 ? res : PI - res;
    }

    uint UpdateSectors(float minHorizon, float maxHorizon, uint globalOccludedBitfield)
    {
        uint startHorizonInt = minHorizon * SECTOR_COUNT;
        uint angleHorizonInt = ceil((maxHorizon - minHorizon) * SECTOR_COUNT);
        uint angleHorizonBitfield = angleHorizonInt > 0 ?
        (0xFFFFFFFF >> (SECTOR_COUNT - angleHorizonInt)) : 0;
        uint currentOccludedBitfield = angleHorizonBitfield << startHorizonInt;
        return globalOccludedBitfield | currentOccludedBitfield;
    }

    //--------------------|
    // :: Pixel Shaders ::|
    //--------------------|
    float4 PS_GenNormals(VS_OUTPUT input) : SV_Target
    {
        float depth = GetDepth(input.uv);
        if (depth >= DepthThreshold)
            return float4(NM_EncodeNormal(float3(0, 0, -1)), 0.0, depth);
        float realDepthMult = EnableDepthMultiplier ? lerp(0.1, 5.0, DepthMultiplier) : 1.0;
        float2 p = bb::PixelSize;
        float3 p_c = UVToViewPos(input.uv, depth * FAR_PLANE * realDepthMult, input.pScale);

        float2 uvL = input.uv - float2(p.x, 0);
        float2 uvR = input.uv + float2(p.x, 0);
        float2 uvT = input.uv - float2(0, p.y);
        float2 uvB = input.uv + float2(0, p.y);

        float depthL = GetDepth(uvL);
        float depthR = GetDepth(uvR);
        float depthT = GetDepth(uvT);
        float depthB = GetDepth(uvB);

        float3 p_l = UVToViewPos(uvL, depthL * FAR_PLANE * realDepthMult, input.pScale);
        float3 p_r = UVToViewPos(uvR, depthR * FAR_PLANE * realDepthMult, input.pScale);
        float3 p_t = UVToViewPos(uvT, depthT * FAR_PLANE * realDepthMult, input.pScale);
        float3 p_b = UVToViewPos(uvB, depthB * FAR_PLANE * realDepthMult, input.pScale);

        float4 edges = NM_CalculateDepthEdges(p_c.z, p_l.z, p_r.z, p_t.z, p_b.z);
        float3 normal = NM_CalculateEdgeWeightedNormal(edges, p_c, p_l, p_r, p_t, p_b);

        return float4(NM_EncodeNormal(normal), 0.0, depth);
    }

    float4 PS_SSAO(VS_OUTPUT input) : SV_Target
    {
        float2 scaled_uv = input.uv / RenderScale;
        if (any(scaled_uv > 1.0))
            discard;

        float center_depth = GetDepth(scaled_uv);
        if (center_depth >= DepthThreshold)
            return 1.0;
        float realDepthMult = EnableDepthMultiplier ? lerp(0.1, 5.0, DepthMultiplier) : 1.0;
        float2 invPScale = 1.0 / input.pScale;
        float3 positionVS = UVToViewPos(scaled_uv, center_depth * FAR_PLANE * realDepthMult, input.pScale);
        float3 normalVS = SampleNeoNormal(scaled_uv);
        positionVS += normalVS * (0.005 * realDepthMult);
        float3 V = normalize(-positionVS);
        float random_val = GetBayer8x8(input.uv);
        float stepDist = (max(AORadius, 0.01)) / float(RaySteps);
        float centerZ = positionVS.z;
        float totalVisibility = 0.0;

        for (int i = 0; i < SampleCount; i++)
        {
            float angle = (float(i) + random_val) * (PI / float(SampleCount));
            float2 dir = float2(cos(angle), sin(angle));
            
            float3 sliceN = normalize(cross(float3(dir, 0.0), V));
            float3 projN = normalVS - sliceN * dot(normalVS, sliceN);
            float projNLen = length(projN);
            float cosN = dot(projN / (projNLen + 1e-6), V);
            float3 T = cross(V, sliceN);
            float N_angle = -sign(dot(projN, T)) * GTAOFastAcos(cosN);
            float2 uvDir = (dir * invPScale * float2(0.5, -0.5));
            float2 uvStep = (uvDir * stepDist) / (centerZ + 1e-6);

            uint globalOccludedBitfield = 0;
            for (int side = -1; side <= 1; side += 2)
            {
                float2 rayDir = dir * float(side);
                float3 rayDirVS = float3(rayDir, 0); 
                float marchProgress = random_val + 0.1;
                [loop]
                for (int j = 0; j < RaySteps; j++)
                {
                    float2 sample_uv = input.uv + (uvStep * float(side) * marchProgress);
                    if (all(saturate(sample_uv) == sample_uv))
                    {
                        float sampleDepth = GetDepth(sample_uv);
                        float currentDist = stepDist * marchProgress;
                        float3 samplePosRay = positionVS + (rayDirVS * currentDist);
                        float3 samplePosVS = samplePosRay * ((sampleDepth * FAR_PLANE) / centerZ);
                        
                        float3 deltaPos = samplePosVS - positionVS;
                        float3 deltaPosBackface = deltaPos - V * Thickness;

                        float2 frontBackHorizon = float2(dot(normalize(deltaPos), V), dot(normalize(deltaPosBackface), V));
                        frontBackHorizon = GTAOFastAcos(frontBackHorizon);
                        float2 horizonAngles = (float(side) * -frontBackHorizon - N_angle + HALF_PI) / PI;
                        
                        horizonAngles = saturate(horizonAngles);
                        float minH = min(horizonAngles.x, horizonAngles.y);
                        float maxH = max(horizonAngles.x, horizonAngles.y);
                        
                        globalOccludedBitfield = UpdateSectors(minH, maxH, globalOccludedBitfield);
                    }
                    marchProgress += 1.0;
                }
            }
            
            float occludedCount = countbits(globalOccludedBitfield);
            totalVisibility += 1.0 - (occludedCount / float(SECTOR_COUNT));
        }

        float visibility = totalVisibility / float(SampleCount);
        float occlusion = 1.0 - visibility;
        occlusion = pow(saturate(occlusion * Intensity), 2.0);
        
        float fade = smoothstep(FadeEnd * 2.0, FadeStart, center_depth);
        occlusion *= fade;

        return 1.0 - saturate(occlusion);
    }
    
    float4 PS_BilateralBlur(VS_OUTPUT input) : SV_Target
    {
        float2 scaled_uv = input.uv / RenderScale;
        if (any(scaled_uv > 1.0))
            discard;
        float2 texelSize = bb::PixelSize * 1.5;
        float centerDepth = GetDepth(scaled_uv);
        
        hfloat totalWeight = 1.0;
        hfloat totalAO = tex2D(sAO, input.uv).r;
        const int2 offsets[14] =
        {
            int2(0, 1), int2(0, -1),
            int2(0, 2), int2(0, -2),
            int2(1, 0), int2(-1, 0),
            int2(1, 1), int2(1, -1), int2(-1, 1), int2(-1, -1),
            int2(1, 2), int2(1, -2), int2(-1, 2), int2(-1, -2)
      
        };

        const float spatialWeights[14] =
        {
            0.8825, 0.8825, // w1
            0.6065, 0.6065, // w3
            0.8825, 0.8825, // w1
            0.7788, 0.7788, 0.7788, 0.7788, // w2
            0.5353, 0.5353, 0.5353, 0.5353 // w4
       
         };

        float sharpnessMult = 1000.0 * BlurSharpness;

        [unroll]
        for (int k = 0; k < 14; k++)
        {
            float2 sampleUV = input.uv + (float2(offsets[k]) * texelSize);
            float sampleDepth = GetDepth(sampleUV / RenderScale);
            hfloat sampleAO = tex2D(sAO, sampleUV).r;

            hfloat depthDiff = abs(centerDepth - sampleDepth);
            hfloat weight = spatialWeights[k] * exp(-depthDiff * sharpnessMult);

            totalAO += sampleAO * weight;
            totalWeight += weight;
        }
        
        return totalAO / totalWeight;
    }

    float4 PS_TAA(VS_OUTPUT input, sampler sHistory)
    {
        float2 scaled_uv = input.uv / RenderScale;
        if (any(scaled_uv > 1.0))
            discard;
        float currentAO = tex2D(sAOBlur, input.uv).r; 
        
        if (!EnableTAA || FRAME_COUNT <= 1)
            return currentAO;

        // Gate on the far plane first, or this pass reprojects sky.
        if (GetDepth(scaled_uv) >= 0.999)
            return currentAO;

        float2 velocity = MV_GetVelocity(input.uv);
        float2 prevUV = scaled_uv + velocity;

        // Reprojection check
        if (any(prevUV < 0.0) || any(prevUV > 1.0))
            return currentAO;

        float historyAO = tex2D(sHistory, prevUV * RenderScale).r;

        // Neighborhood Clamping 
        float minNeighborhood = 1.0;
        float maxNeighborhood = 0.0;
        
        float2 texel = bb::PixelSize / RenderScale;
        [unroll]
        for (int x = -1; x <= 1; x++)
        {
            [unroll]
            for (int y = -1; y <= 1; y++)
            {
                float neighbor = tex2D(sAOBlur, (scaled_uv + float2(x, y) * texel) * RenderScale).r;
                minNeighborhood = min(minNeighborhood, neighbor);
                maxNeighborhood = max(maxNeighborhood, neighbor);
            }
        }
        
        // Clamp History 
        historyAO = clamp(historyAO, minNeighborhood, maxNeighborhood);

        // Confidence
        float confidence = MV_GetConfidence(input.uv);
        confidence = TAA_GetNormalHistoryConfidence(
            scaled_uv, prevUV, TAA_GetStableDepth(scaled_uv, GetDepth(scaled_uv)), confidence);

        // Blend
        return lerp(currentAO, historyAO, TemporalStability * confidence);
    }

    float4 PS_Accumulate0(VS_OUTPUT input) : SV_Target
    {
        if (uint(FRAME_COUNT) % 2u != 0u)
            discard;
        return PS_TAA(input, sHistory1);
    }

    float4 PS_Accumulate1(VS_OUTPUT input) : SV_Target
    {
        if (uint(FRAME_COUNT) % 2u == 0u)
            discard;
        return PS_TAA(input, sHistory0);
    }

    float4 PS_Output(VS_OUTPUT input) : SV_Target
    {
        float4 originalColor = GetColor(input.uv);
        float occlusion = 1.0;

        if (EnableTAA)
        {
            if (uint(FRAME_COUNT) % 2u == 0u)
                occlusion = tex2D(sHistory0, input.uv).r;
            else
                occlusion = tex2D(sHistory1, input.uv).r;
        }
        else
        {
            occlusion = tex2D(sAOBlur, input.uv * RenderScale).r;
        }

        if (ViewMode == 0) // Normal
        {
            originalColor.rgb *= occlusion;
            originalColor.rgb = lerp(originalColor.rgb, OcclusionColor.rgb, 1.0 - occlusion);
            return originalColor;
        }
        else if (ViewMode == 1) // AO Only
            return occlusion;
        else if (ViewMode == 2) // Depth
            return GetDepth(input.uv);
            
        return originalColor;
    }

    technique NeoSSAO
    <
    ui_label = "BaBa: NeoSSAO";
    ui_tooltip = "Requires 'BaBa: Launcher' enabled ABOVE this effect in the list.\n"
                 "Without it, depth/normals will be invalid and the effect won't work correctly.\n"
                 "To run standalone instead, set 'BABA_USE_LEGACY_PIPELINE' to 1 in the preprocessor definitions.";
    >
    {
        #if !_BABA_USE_LAUNCHER
        pass GenNormals
        {
            VertexShader = VS_NeoSSAO;
            PixelShader = PS_GenNormals;
            RenderTarget = normalTex;
        }
        #endif
        pass SSAOPass
        {
            VertexShader = VS_NeoSSAO;
            PixelShader = PS_SSAO;
            RenderTarget = AO;
        }
        pass DenoisePass
        {
            VertexShader = VS_NeoSSAO;
            PixelShader = PS_BilateralBlur;
            RenderTarget = AOBlur;
        }
        pass Accumulate0
        {
            VertexShader = VS_NeoSSAO;
            PixelShader = PS_Accumulate0;
            RenderTarget = History0;
        }
        pass Accumulate1
        {
            VertexShader = VS_NeoSSAO;
            PixelShader = PS_Accumulate1;
            RenderTarget = History1;
        }
        pass OutputPass
        {
            VertexShader = VS_NeoSSAO;
            PixelShader = PS_Output;
        }
    }
}
