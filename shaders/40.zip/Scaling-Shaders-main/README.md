# Scaling Shaders

Both shaders are distributed in the `Shaders/Retro Shaders` folder so ReShade's installer can install them as one package.

## Resizer

Resizer allows you to freely crop an area of the screen, downscale only that area, and optionally then upscale it to a size of your choosing, using either linear or point filtering.
It is intended primarily for situations where you need to scale down the image while maintaining a native resolution, and/or remove or replace pillarboxing and letterboxing that is part of the original content.

Resizer also allows for recentering content that is not displayed in the center of the screen, for old games that insist on sticking the image in the corner of the screen no matter what you do. 

### How to use

- Set the content resolution to the size of the part of the screen you want to crop down to, for example 1440x1080 if you want a 4:3 section of a 1080p frame.

- Set the intermediate resolution to the resolution you want to downscale the cropped area to.

- Set the final resolution to the resolution you want to upscale the image back to. I recommend using an integer multiple of the downscale resolution for clean results.

- To center an off-center image, use the Content Top-Left fields to specify the top-left pixel of the content. For example if the content is displayed in the top left corner of the screen, enter 0, 0.

The shader defaults to point filtering, but you can change this to linear in the preprocessor definitions if you want smoothed results.


### Example

A game uses a 1080p, 16:9 framebuffer, but is pillarboxed to 4:3, and you want to play it at 640x480 for whatever reason, and you want to display that 480p image at 2x scale.
You would do the following:

- Set the content resolution to 1440x1080.

- Set the intermediate resolution to 640x480.

- Set the final resolution to 1280x960.

## PS1 RGB555 Dither

`PS1Dither.fx` applies the PlayStation GPU's 4x4 ordered dither matrix followed by RGB555 quantization. Each channel is offset in 8-bit color space, truncated to one of 32 levels, and expanded back to the output range.

The **Dither Grid Width** and **Dither Grid Height** select the simulated source-pixel grid. Leave them at the backbuffer size for one dither cell per output pixel. When a game is being upscaled, divide the content resolution by the upscale factor. For example, a 1920x1080 image at 4x upscale should use a 480x270 dither grid. This keeps the pattern aligned with the source raster and enlarges each dither cell with the image.

Keep **Content Width** and **Content Height** at the backbuffer dimensions unless the game image occupies only part of it. For letterboxed, pillarboxed, or otherwise inset content, enter the content's output size and its top-left X/Y offset so that the matrix starts at the content edge.

Place the technique after scaling effects. **Enable Dithering** can be disabled to retain RGB555 quantization without the spatial matrix. This may be useful if you want PS1 colour behaviour but can't or don't want to use a CRT shader that effectively blends the dither.

### Accuracy limitation

ReShade receives only the completed backbuffer. The shader therefore reproduces the matrix, channel arithmetic, RGB555 levels, and raster-grid alignment, but it cannot distinguish UI rectangles from dithered geometry or reproduce separate RGB555 framebuffer writes and blending for every primitive. An implementation inside the game renderer can be more exact.
